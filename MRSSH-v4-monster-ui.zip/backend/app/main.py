from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from .core.config import settings
from .core.security import create_token, get_current_user
from .services.ssh_service import dashboard, USERS

app = FastAPI(title="MRSSH v4 Monster API", version="4.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class LoginIn(BaseModel):
    username: str
    password: str

@app.get("/health")
def health():
    return {"ok": True, "service": "mrssh-v4"}

@app.post("/auth/login")
def login(data: LoginIn):
    if data.username == settings.ADMIN_USERNAME and data.password == settings.ADMIN_PASSWORD:
        return {"access_token": create_token(data.username), "token_type":"bearer", "user":{"username":data.username,"role":"super_admin"}}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.get("/dashboard")
def get_dashboard(user=Depends(get_current_user)):
    return dashboard()

@app.get("/users")
def get_users(user=Depends(get_current_user)):
    return USERS

@app.post("/users")
def create_user(payload: dict, user=Depends(get_current_user)):
    item = {"username": payload.get("username","new_user"), "owner":"root", "status":"active", "traffic":"0 GB / 100 GB", "usedPercent":0, "expire":payload.get("expire","2026-12-30"), "online":False, "ip":"-", "connections":"0/1"}
    USERS.insert(0, item)
    return item
