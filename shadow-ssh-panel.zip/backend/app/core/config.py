from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    project_name: str = Field(default="Shadow SSH Panel", alias="PROJECT_NAME")
    api_secret_key: str = Field(default="please-change-this-secret", alias="API_SECRET_KEY")
    admin_username: str = Field(default="admin", alias="ADMIN_USERNAME")
    admin_password: str = Field(default="change-me-now", alias="ADMIN_PASSWORD")
    cors_origins: str = Field(default="http://localhost", alias="CORS_ORIGINS")
    database_url: str = Field(default="sqlite:///./shadow_panel.db", alias="DATABASE_URL")

    @property
    def origins(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]

settings = Settings()
