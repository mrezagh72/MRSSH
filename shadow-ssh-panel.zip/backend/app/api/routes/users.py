from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from app.api.deps import current_user
from app.services.ssh_service import ssh_service

router = APIRouter(prefix="/users", tags=["users"])

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[a-zA-Z0-9_\-]+$")
    password: str = Field(min_length=6, max_length=128)
    days: int = Field(default=30, ge=1, le=3650)
    traffic_gb: int | None = Field(default=None, ge=1, le=100000)

@router.get("")
def list_users(_: dict = Depends(current_user)):
    return [user.__dict__ for user in ssh_service.list_users()]

@router.post("")
def create_user(payload: UserCreate, _: dict = Depends(current_user)):
    return ssh_service.create_user(payload.username, payload.password, payload.days, payload.traffic_gb)
