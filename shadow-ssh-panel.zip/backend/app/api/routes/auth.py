from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from app.core.config import settings
from app.core.security import create_access_token, verify_password
from app.api.deps import current_user

router = APIRouter(prefix="/auth", tags=["auth"])

class LoginRequest(BaseModel):
    username: str
    password: str

@router.post("/login")
def login(payload: LoginRequest):
    if payload.username != settings.admin_username or not verify_password(payload.password, settings.admin_password):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return {
        "access_token": create_access_token(payload.username),
        "token_type": "bearer",
        "user": {"username": payload.username, "role": "super_admin"},
    }

@router.get("/me")
def me(user: dict = Depends(current_user)):
    return user
