from fastapi import APIRouter, Depends
from app.api.deps import current_user
from app.services.ssh_service import ssh_service

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@router.get("/summary")
def summary(_: dict = Depends(current_user)):
    users = ssh_service.list_users()
    return {
        "total_users": 1425,
        "online_users": 256,
        "total_traffic_tb": 92.4,
        "active_servers": 3,
        "expiring_soon": 48,
        "traffic_series": [8.7, 10.6, 11.8, 13.9, 13.1, 18.7, 13.3, 17.2, 19.8],
        "status": {"active": 1053, "expired": 256, "disabled": 116},
        "top_users": [
            {"username": "amir_admin", "traffic": "2.45 TB"},
            {"username": "sina_style", "traffic": "1.23 TB"},
            {"username": "hossein_2024", "traffic": "980 GB"},
            {"username": "ali_ax", "traffic": "870 GB"},
        ],
        "servers": [
            {"name": "IR-Tehran-01", "ip": "185.123.45.67", "status": "online", "uptime": "15d 8h"},
            {"name": "IR-Tehran-02", "ip": "91.98.76.54", "status": "online", "uptime": "22d 14h"},
            {"name": "DE-Frankfurt-01", "ip": "45.87.12.34", "status": "online", "uptime": "7d 3h"},
        ],
        "resources": {"cpu": 23, "ram": 45, "disk": 67},
    }
