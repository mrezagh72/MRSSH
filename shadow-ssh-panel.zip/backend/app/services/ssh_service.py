"""SSH operations boundary.

Do not run raw user input through shell=True. Ever. The void already has enough snacks.
Implement real Linux operations here or replace this with calls to a server-side agent.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class SSHUser:
    username: str
    status: str
    traffic_used_gb: float
    traffic_limit_gb: float | None
    expire_at: str
    last_ip: str
    online: bool

class SSHService:
    def list_users(self) -> list[SSHUser]:
        return [
            SSHUser("amir_admin", "active", 1450, None, "2026-06-20", "185.123.45.67", True),
            SSHUser("sina_style", "active", 1230, 2000, "2026-05-25", "37.152.12.89", True),
            SSHUser("hossein_2024", "active", 980, 1000, "2026-05-22", "5.63.12.34", True),
            SSHUser("ali_ax", "expired", 512, 500, "2026-05-18", "185.55.12.98", False),
            SSHUser("mmd_service", "active", 760, None, "2026-07-20", "91.98.76.54", True),
        ]

    def create_user(self, username: str, password: str, days: int, traffic_gb: int | None):
        # TODO: implement via safe subprocess list args or remote agent API.
        return {
            "username": username,
            "expire_at": (datetime.utcnow() + timedelta(days=days)).date().isoformat(),
            "traffic_limit_gb": traffic_gb,
            "status": "created",
        }

ssh_service = SSHService()
