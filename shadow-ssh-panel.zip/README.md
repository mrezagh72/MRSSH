# Shadow SSH Panel

A modern SSH management panel MVP with a dark neon dashboard UI, FastAPI backend, and Docker Compose deployment.

> This is a starter project. The UI and API are ready; actual Linux SSH user operations are intentionally abstracted behind `backend/app/services/ssh_service.py` so you can implement them safely per server.

## Features

- Dark cyberpunk dashboard UI
- User list, traffic, server status, recent activity
- JWT-ready auth structure
- Role/permission friendly backend structure
- Docker Compose for panel + API
- Nginx reverse proxy
- Installer script
- Mock data API for immediate testing
- Clean structure for future SSH Agent integration

## Stack

- Frontend: React + Vite + TypeScript
- Backend: FastAPI + Python
- DB: SQLite by default for MVP
- Deploy: Docker Compose + Nginx

## Quick install

```bash
cp .env.example .env
bash scripts/install.sh
```

Then open:

```text
http://SERVER_IP
```

Default login for MVP:

```text
username: admin
password: change-me-now
```

Change this in `.env` before production. Seriously. The internet is not a petting zoo.

## Production notes

Before public deployment:

1. Change all secrets in `.env`
2. Replace default admin password
3. Configure HTTPS
4. Restrict CORS origin
5. Implement real SSH operations inside `ssh_service.py` or use a separate server agent
6. Move from SQLite to PostgreSQL if you expect real traffic
7. Enable rate limiting at Nginx or API level

## Project structure

```text
backend/   FastAPI backend
frontend/  React dashboard
nginx/     Reverse proxy config
scripts/   Install and utility scripts
```

## GitHub upload

Upload this whole folder as a GitHub repository or upload the generated ZIP file.

