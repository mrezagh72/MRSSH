import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, Archive, Bell, Box, ChevronRight, Clock, Database, Gauge, Globe2, HardDrive, Home, KeyRound, LayoutDashboard, Lock, LogOut, Moon, Plus, Search, Server, Settings, Shield, Users, Wifi } from 'lucide-react';
import './styles.css';

const API = '/api';

type User = {
  username: string;
  status: string;
  traffic_used_gb: number;
  traffic_limit_gb: number | null;
  expire_at: string;
  last_ip: string;
  online: boolean;
};

type Summary = {
  total_users: number;
  online_users: number;
  total_traffic_tb: number;
  active_servers: number;
  expiring_soon: number;
  traffic_series: number[];
  status: { active: number; expired: number; disabled: number };
  top_users: { username: string; traffic: string }[];
  servers: { name: string; ip: string; status: string; uptime: string }[];
  resources: { cpu: number; ram: number; disk: number };
};

const fallbackSummary: Summary = {
  total_users: 1425,
  online_users: 256,
  total_traffic_tb: 92.4,
  active_servers: 3,
  expiring_soon: 48,
  traffic_series: [8.7, 10.6, 11.8, 13.9, 13.1, 18.7, 13.3, 17.2, 19.8],
  status: { active: 1053, expired: 256, disabled: 116 },
  top_users: [
    { username: 'amir_admin', traffic: '2.45 TB' },
    { username: 'sina_style', traffic: '1.23 TB' },
    { username: 'hossein_2024', traffic: '980 GB' },
    { username: 'ali_ax', traffic: '870 GB' },
  ],
  servers: [
    { name: 'IR-Tehran-01', ip: '185.123.45.67', status: 'online', uptime: '15d 8h' },
    { name: 'IR-Tehran-02', ip: '91.98.76.54', status: 'online', uptime: '22d 14h' },
    { name: 'DE-Frankfurt-01', ip: '45.87.12.34', status: 'online', uptime: '7d 3h' },
  ],
  resources: { cpu: 23, ram: 45, disk: 67 },
};

const fallbackUsers: User[] = [
  { username: 'amir_admin', status: 'active', traffic_used_gb: 1450, traffic_limit_gb: null, expire_at: '2026-06-20', last_ip: '185.123.45.67', online: true },
  { username: 'sina_style', status: 'active', traffic_used_gb: 1230, traffic_limit_gb: 2000, expire_at: '2026-05-25', last_ip: '37.152.12.89', online: true },
  { username: 'hossein_2024', status: 'active', traffic_used_gb: 980, traffic_limit_gb: 1000, expire_at: '2026-05-22', last_ip: '5.63.12.34', online: true },
  { username: 'ali_ax', status: 'expired', traffic_used_gb: 512, traffic_limit_gb: 500, expire_at: '2026-05-18', last_ip: '185.55.12.98', online: false },
  { username: 'mmd_service', status: 'active', traffic_used_gb: 760, traffic_limit_gb: null, expire_at: '2026-07-20', last_ip: '91.98.76.54', online: true },
];

function token() { return localStorage.getItem('shadow_token'); }

async function api(path: string, options: RequestInit = {}) {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token()) headers.Authorization = `Bearer ${token()}`;
  const res = await fetch(`${API}${path}`, { ...options, headers: { ...headers, ...(options.headers || {}) } });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function Login({ onLogin }: { onLogin: () => void }) {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('change-me-now');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const data = await api('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
      localStorage.setItem('shadow_token', data.access_token);
      onLogin();
    } catch {
      setError('Login failed. Check credentials or API status.');
    } finally { setLoading(false); }
  }

  return <div className="login-shell">
    <form className="login-card" onSubmit={submit}>
      <div className="brand big"><div className="logo"><Shield size={28}/></div><div><b>SHADOW SSH</b><span>PANEL</span></div></div>
      <h1>Control your SSH universe</h1>
      <p>Secure admin panel starter for SSH users, traffic and server monitoring.</p>
      <label>Username<input value={username} onChange={e => setUsername(e.target.value)} /></label>
      <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} /></label>
      {error && <div className="error">{error}</div>}
      <button className="primary" disabled={loading}>{loading ? 'Signing in...' : 'Login'}</button>
    </form>
  </div>;
}

function Sidebar() {
  const items = [
    [LayoutDashboard, 'Dashboard', ''], [Users, 'Users', '1425'], [Plus, 'Create User', ''], [Shield, 'Resellers', '32'], [Server, 'Servers', '3'], [Wifi, 'Online Users', ''], [Gauge, 'Traffic Monitor', ''], [Archive, 'Backups', ''], [KeyRound, 'API & Tokens', ''], [Settings, 'Settings', '']
  ] as const;
  return <aside className="sidebar">
    <div className="brand"><div className="logo"><Shield size={22}/></div><div><b>SHADOW SSH</b><span>PANEL</span></div></div>
    <nav>{items.map(([Icon, label, badge], i) => <a className={i === 0 ? 'active' : ''} key={label}><Icon size={18}/><span>{label}</span>{badge && <em>{badge}</em>}<ChevronRight className="chev" size={16}/></a>)}</nav>
    <div className="system-time"><Clock size={16}/><span>System Time</span><b>{new Date().toLocaleString()}</b><small>Tehran, Iran</small></div>
    <div className="profile"><div className="avatar">A</div><div><b>Admin</b><span>Super Admin</span></div><LogOut size={18}/></div>
  </aside>;
}

function StatCard({ title, value, icon: Icon, tone }: { title: string, value: string | number, icon: any, tone: string }) {
  return <div className={`card stat ${tone}`}><div><span>{title}</span><strong>{value}</strong><small>▲ 12.5% vs last month</small></div><div className="stat-icon"><Icon size={30}/></div></div>;
}

function Ring({ label, value }: { label: string, value: number }) {
  return <div className="ring" style={{ background: `conic-gradient(var(--accent) ${value * 3.6}deg, rgba(255,255,255,.08) 0deg)` }}><div><b>{value}%</b><span>{label}</span></div></div>;
}

function Dashboard() {
  const [summary, setSummary] = useState<Summary>(fallbackSummary);
  const [users, setUsers] = useState<User[]>(fallbackUsers);
  const [query, setQuery] = useState('');

  useEffect(() => {
    api('/dashboard/summary').then(setSummary).catch(() => undefined);
    api('/users').then(setUsers).catch(() => undefined);
  }, []);

  const chartData = useMemo(() => summary.traffic_series.map((value, index) => ({ day: `Day ${index + 1}`, value })), [summary]);
  const filtered = users.filter(u => u.username.toLowerCase().includes(query.toLowerCase()));

  return <div className="app-shell">
    <Sidebar />
    <main className="main">
      <header className="topbar"><div className="search"><Search size={18}/><input placeholder="Search for users, resellers, servers..." value={query} onChange={e => setQuery(e.target.value)} /><kbd>Ctrl + K</kbd></div><div className="icons"><span>🇮🇷</span><Moon/><Bell/><Globe2/></div></header>
      <section className="stats-grid">
        <StatCard title="TOTAL USERS" value={summary.total_users.toLocaleString()} icon={Users} tone="purple" />
        <StatCard title="ONLINE USERS" value={summary.online_users} icon={Activity} tone="green" />
        <StatCard title="TOTAL TRAFFIC" value={`${summary.total_traffic_tb} TB`} icon={Database} tone="blue" />
        <StatCard title="ACTIVE SERVERS" value={summary.active_servers} icon={Server} tone="orange" />
        <StatCard title="EXPIRING SOON" value={summary.expiring_soon} icon={Bell} tone="red" />
      </section>
      <section className="grid-3">
        <div className="card chart"><div className="card-head"><h3>Traffic Usage</h3><button>7 Days</button></div><ResponsiveContainer width="100%" height={220}><AreaChart data={chartData}><defs><linearGradient id="traffic" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.7}/><stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/></linearGradient></defs><XAxis dataKey="day" stroke="#6b7280"/><YAxis stroke="#6b7280"/><Tooltip/><Area type="monotone" dataKey="value" stroke="#8b5cf6" fill="url(#traffic)" strokeWidth={3}/></AreaChart></ResponsiveContainer></div>
        <div className="card status-card"><h3>User Status</h3><div className="donut"><div>{summary.total_users}<span>Total</span></div></div><ul><li><b className="green-dot"/>Active <span>{summary.status.active}</span></li><li><b className="red-dot"/>Expired <span>{summary.status.expired}</span></li><li><b className="orange-dot"/>Disabled <span>{summary.status.disabled}</span></li></ul></div>
        <div className="card"><h3>Top Users</h3>{summary.top_users.map((u, i) => <div className="top-user" key={u.username}><span>#{i + 1}</span><b>{u.username}</b><em>{u.traffic}</em></div>)}</div>
      </section>
      <section className="content-grid">
        <div className="card table-card"><div className="card-head"><h3>Recent Users</h3><button className="primary small"><Plus size={16}/>Create User</button></div><table><thead><tr><th>User</th><th>Status</th><th>Traffic</th><th>Expire Date</th><th>IP / Last Seen</th><th>Actions</th></tr></thead><tbody>{filtered.map(u => <tr key={u.username}><td><div className="user-cell"><div className="mini-avatar">{u.username[0].toUpperCase()}</div><div><b>{u.username}</b><span>{u.traffic_limit_gb ? `${u.traffic_limit_gb} GB` : 'No Limit'}</span></div></div></td><td><span className={`pill ${u.status}`}>{u.status}</span></td><td><div>{u.traffic_used_gb} GB / {u.traffic_limit_gb ?? '∞'}</div><div className="bar"><i style={{ width: `${Math.min(100, u.traffic_limit_gb ? (u.traffic_used_gb/u.traffic_limit_gb)*100 : 35)}%` }}/></div></td><td>{u.expire_at}</td><td>{u.last_ip}<small>{u.online ? 'online now' : 'offline'}</small></td><td><button className="ghost">Edit</button><button className="ghost">View</button></td></tr>)}</tbody></table></div>
        <aside className="rightcol"><div className="card"><h3>Server Status</h3>{summary.servers.map(s => <div className="server-row" key={s.name}><Server size={18}/><div><b>{s.name}</b><span>{s.ip}</span></div><em>{s.status}</em></div>)}</div><div className="card resources"><h3>System Resources</h3><div className="rings"><Ring label="CPU" value={summary.resources.cpu}/><Ring label="RAM" value={summary.resources.ram}/><Ring label="DISK" value={summary.resources.disk}/></div></div><div className="card quick"><h3>Quick Actions</h3>{['Create User', 'Backup Now', 'View Logs', 'System Settings'].map(x => <button key={x}><Box size={17}/>{x}<ChevronRight size={16}/></button>)}</div></aside>
      </section>
    </main>
  </div>;
}

function App() {
  const [logged, setLogged] = useState(Boolean(token()));
  return logged ? <Dashboard /> : <Login onLogin={() => setLogged(true)} />;
}

createRoot(document.getElementById('root')!).render(<App />);
